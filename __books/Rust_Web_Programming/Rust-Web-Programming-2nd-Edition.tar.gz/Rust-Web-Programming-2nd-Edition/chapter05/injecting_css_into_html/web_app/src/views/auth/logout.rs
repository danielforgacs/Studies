

pub async fn logout() -> String {
    format!("Logout view")
}
