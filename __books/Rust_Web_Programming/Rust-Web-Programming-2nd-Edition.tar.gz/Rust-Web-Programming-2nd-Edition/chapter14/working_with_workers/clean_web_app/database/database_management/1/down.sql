
DROP TABLE to_do
